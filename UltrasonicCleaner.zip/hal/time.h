#ifndef __HAL_TIME_H__
#define __HAL_TIME_H__

#ifdef __cplusplus
extern "C" {
#endif

void hal_time_init(void);
void hal_time_tick_1ms(void);

#ifdef __cplusplus
}   /* extern "C" */
#endif

#endif
