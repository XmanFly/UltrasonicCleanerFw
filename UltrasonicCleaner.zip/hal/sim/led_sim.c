#include "hal/led.h"

#ifdef PLATFORM_QT

void led_hw_init(void)
{

}

void led_hw_start(void)
{

}

#endif
